# SHW Jewelry Telegram Mini App — Updated

Fields:
- Full Name *
- Address *
- Phone Number *
- Email *
- How did you hear about us?
- Have you worked with brands before? *
- Have you ever been convicted of a crime? *
- Payment Method * — E-check
- Bank Name *
- Agreement checkbox

TikTok, Instagram, and digital signature were removed.

Set BOT_TOKEN and ADMIN_CHAT_ID as secure environment variables on your host. Never publish the BotFather token in the website code.
