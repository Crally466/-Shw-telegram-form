import express from "express";
import dotenv from "dotenv";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
const app=express(), __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"100kb"})); app.use(express.static(path.join(__dirname,"public")));
const BOT_TOKEN=process.env.BOT_TOKEN, ADMIN_CHAT_ID=process.env.ADMIN_CHAT_ID;
function valid(initData){
 if(!initData||!BOT_TOKEN)return false;
 const p=new URLSearchParams(initData), hash=p.get("hash"); if(!hash)return false; p.delete("hash");
 const s=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\n");
 const key=crypto.createHmac("sha256","WebAppData").update(BOT_TOKEN).digest();
 const calc=crypto.createHmac("sha256",key).update(s).digest("hex");
 return calc.length===hash.length&&crypto.timingSafeEqual(Buffer.from(calc),Buffer.from(hash));
}
const clean=(v,n=500)=>String(v??"").trim().slice(0,n);
app.post("/api/apply",async(req,res)=>{
 try{
  if(!valid(req.body?.initData))return res.status(401).json({ok:false,error:"Invalid Telegram session."});
  const a=req.body.application||{};
  const fields={
   fullName:clean(a.fullName,120), email:clean(a.email,160), phone:clean(a.phone,60),
   address:clean(a.address,300), brands:clean(a.brands,10), crime:clean(a.crime,10),
   payment:clean(a.payment,30), bankName:clean(a.bankName,120), heardFrom:clean(a.heardFrom,120)
  };
  if(!fields.fullName||!fields.email||!fields.phone||!fields.address||!fields.brands||
     !fields.crime||fields.payment!=="E-check"||!fields.bankName||!a.agree)
    return res.status(400).json({ok:false,error:"Please complete all required fields."});
  const msg=`✨ SHW JEWELRY — NEW APPLICATION

Name: ${fields.fullName}
Email: ${fields.email}
Phone: ${fields.phone}
Address: ${fields.address}
Worked with brands before: ${fields.brands}
Ever been convicted of a crime: ${fields.crime}
Payment method: ${fields.payment}
Bank name: ${fields.bankName}
How did you hear about us: ${fields.heardFrom||"—"}
Agreement accepted: Yes`;
  const r=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{
   method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({chat_id:ADMIN_CHAT_ID,text:msg})
  });
  if(!r.ok)return res.status(502).json({ok:false,error:"Telegram notification failed."});
  res.json({ok:true});
 }catch(e){console.error(e);res.status(500).json({ok:false,error:"Server error."});}
});
app.get("*splat",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("SHW form running"));
